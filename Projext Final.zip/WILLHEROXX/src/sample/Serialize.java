package sample;

public interface Serialize {
    void serialize();
    void deserialize();
}
