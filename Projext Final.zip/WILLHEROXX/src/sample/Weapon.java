package sample;

public class Weapon {
    String type;
    int dmg;
}
