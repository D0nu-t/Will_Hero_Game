package sample;

import javafx.scene.image.ImageView;

public class Obstacle extends Item{
    private ImageView obs;
}
