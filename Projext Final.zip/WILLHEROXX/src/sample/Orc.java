package sample;

import javafx.scene.image.ImageView;

public class Orc extends NPC{
    private ImageView orc;
}
