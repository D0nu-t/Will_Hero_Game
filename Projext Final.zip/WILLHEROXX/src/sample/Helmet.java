package sample;

import javafx.scene.image.ImageView;

public class Helmet {
    private ImageView imageView;
}
