package sample;

public interface Movement {
    void Front();
    void Back();
    void Jump();
    void Parallax();
}
