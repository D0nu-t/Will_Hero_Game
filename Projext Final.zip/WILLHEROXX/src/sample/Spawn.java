package sample;

public interface Spawn {
    void spawn();
    void despawn();
}
