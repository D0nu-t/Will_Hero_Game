package sample;

public class Chest extends Item{
    private Weapon content;

    public Weapon getContent() {
        return content;
    }
}
