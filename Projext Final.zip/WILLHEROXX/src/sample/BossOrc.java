package sample;

import javafx.scene.image.ImageView;

public class BossOrc extends Orc{
    private ImageView bossOrc;
}
