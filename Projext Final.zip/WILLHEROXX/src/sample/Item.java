package sample;

public class Item{
    protected String type;
    protected Coordinate location;

    public Coordinate getLocation() {
        return location;
    }

    public void setLocation(Coordinate location) {
        this.location = location;
    }

}
